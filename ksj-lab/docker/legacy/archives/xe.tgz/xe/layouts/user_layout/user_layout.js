// <![CDATA[
jQuery(function($){
	//
});
// ]]>
