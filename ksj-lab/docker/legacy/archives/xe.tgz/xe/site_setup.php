<?php
	$config = file_get_contents("./files/config/db.config.php");
	$config = preg_replace("/192.168.145.144/", $_SERVER['SERVER_ADDR'], $config);

	$fp = fopen("./files/config/db.config.php", "w");
	fwrite($fp, $config);
	fclose($fp);

	mysql_connect("localhost", "root", "1234");
	mysql_select_db("xe_db");
	mysql_query("update xe_sites set domain='{$_SERVER['SERVER_ADDR']}/xe/' where site_srl=0");
